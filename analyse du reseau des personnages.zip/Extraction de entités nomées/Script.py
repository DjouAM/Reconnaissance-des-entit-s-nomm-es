import os
import spacy
import networkx as nx
import matplotlib.pyplot as plt
import pdfplumber
from itertools import combinations
from collections import Counter

# Charger le modèle SpaCy pour le français
nlp = spacy.load("fr_core_news_sm")

# Chemin du fichier PDF 
file_path = r"C:\Users\AMMIC\OneDrive\Desktop\yasmina-khadra-ce-que-le-jour-doit-a-la-nuit.pdf"
if not os.path.exists(file_path):
    print("Erreur : Le fichier PDF n'existe pas.")
    exit()

# Étape 1 : Extraction des personnages (NER - Named Entity Recognition)
print("Étape 1 : Extraction des personnages...")

# Extraction du texte depuis le PDF
text = ""
with pdfplumber.open(file_path) as pdf:
    for page in pdf.pages:
        page_text = page.extract_text()
        if page_text:
            text += page_text + "\n"

# Vérifier si du texte a été extrait
if not text.strip():
    print("Erreur : Aucun texte n'a été extrait du PDF.")
    exit()

# Traitement du texte avec SpaCy
doc = nlp(text)

# Extraire les personnages (entités de type PERSON)
characters = [ent.text.strip() for ent in doc.ents if ent.label_ == "PER"]

# Nettoyage des noms de personnages
valid_chars = []
for char in characters:
    words = char.split()
    if len(words) <= 2 and all(word[0].isupper() for word in words):  # Vérifier majuscules
        valid_chars.append(char)

# Supprimer les doublons
characters = list(set(valid_chars))

if not characters:
    print("Aucun personnage détecté.")
    exit()

print(f"{len(characters)} personnages extraits : {characters[:10]}...")  # Aperçu

# Étape 2 : Détection des interactions entre personnages
print("Étape 2 : Détection des interactions...")

# Parcourir le texte phrase par phrase
sentences = [sent.text for sent in doc.sents]
co_occurrences = Counter()

for sentence in sentences:
    entities = list(set([ent.text.strip() for ent in nlp(sentence).ents if ent.label_ == "PER"]))
    entities = [ent for ent in entities if ent in characters]
    if len(entities) > 1:
        for pair in combinations(entities, 2):
            co_occurrences[pair] += 1

print(f"{len(co_occurrences)} interactions détectées.")

# Étape 3 : Construction et visualisation du graphe
print("Étape 3 : Construction du graphe identique à l’image...")

# Création d'un graphe orienté
G = nx.DiGraph()
G.add_nodes_from(characters)

# Ajouter tous les liens, sans filtrage
for (char1, char2), weight in co_occurrences.items():
    G.add_edge(char1, char2, weight=weight)

# Disposition circulaire pour ressembler à ton image
plt.figure(figsize=(15, 8))
pos = nx.kamada_kawai_layout(G)  # Layout similaire à ton image

# Dessiner les relations avec flèches
nx.draw_networkx_edges(G, pos, edge_color="black", width=0.5, alpha=0.8, arrowstyle="->", arrows=True)

# Dessiner les personnages (nœuds)
nx.draw_networkx_nodes(G, pos, node_size=10, node_color="black", alpha=0.7)

# Ajouter les noms des personnages (petite taille pour ressembler à l’image)
nx.draw_networkx_labels(G, pos, font_size=7, font_color="black")

# Supprimer les axes pour un rendu propre
plt.axis("off")

# Afficher le graphe
plt.show()

print("Graphe généré avec succès !")
